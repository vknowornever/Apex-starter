
    export const LISTITEMS: any[] = [
        {"url":"/page", "name":"Page", "icon":"ft-home"},
        {"url":"/pages/login", "name":"Login", "icon":"ft-log-in"},
    ]

